import 'package:flutter/material.dart';
import 'package:trabalhofinal/pages/tela.conquistas.dart';
import 'package:trabalhofinal/pages/tela.escalacao.dart';
import 'package:trabalhofinal/pages/tela.login.dart';
import 'package:trabalhofinal/pages/tela.menu.dart';

void main() => runApp(Tricolor());

class Tricolor extends StatelessWidget {
  const Tricolor ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplicativo Tricolor',
      debugShowCheckedModeBanner: false,
      home: TelaLogin(),
      initialRoute: 'Tela Login',
      routes: {
        'Tela Login': (context) => const TelaLogin(),
        'Tela Menu': (context) => const TelaMenu(),
        'Tela Conquistas': (context) => const TelaConquistas(),
        'Tela Escalacao': (context) => const TelaEscalacao(),
      },
    );
  }
}

class Mensagem {
  final String nome;
  Mensagem(this.nome);
}