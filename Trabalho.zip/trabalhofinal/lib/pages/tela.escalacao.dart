import 'package:flutter/material.dart';

class TelaEscalacao extends StatelessWidget {
  const TelaEscalacao({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red[900],
        title: Text('Escalação do jogo de hoje!',
          style: TextStyle(color: Colors.black))
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(20),
          child: Column(            
            children: [
              Image.asset('assets/images/Escalacao.jpg'),
               SizedBox(
                height: 20,
               ),
            ],
          ),
        ),
      ),
    );
  }
}