import 'package:flutter/material.dart';

class TelaSobre extends StatelessWidget {
  const TelaSobre({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red[900],
        title:
          Text('Sobre',
          style: TextStyle(color: Colors.black))
      ),
      body: SingleChildScrollView(
        child: Container(
          color: Colors.red[200],
          margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
          width: double.infinity,
          child: Column(
            children: [
              Text('Nome do desenvolvedor: Victor Vendruscolo Araujo'),
              Image.asset('assets/images/FotoDev.png'),
              Text('Tema escolhido: Um aplicativo sobre o maior time do Brasil!'),
              Text('Objetivo do aplicativo: demonstrar meu amor por esse clube!'),              
            ],
          ),
        ),
      ),
    );
  }
}