import 'package:flutter/material.dart';

class TelaConquistas extends StatelessWidget {
  const TelaConquistas({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red[900],
        title: Text('Conquistas',
          style: TextStyle(color: Colors.black))
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(20),
          child: Column(            
            children: [
              Image.asset('assets/images/Mundial05.png'),
                SizedBox(
                  height: 20,
                ),
              Image.asset('assets/images/Libertadores05.png'),
                SizedBox(
                  height: 20,
                ),
              Image.asset('assets/images/Mundial93.png'),
                SizedBox(
                  height: 20,
                ),
              Image.asset('assets/images/Libertadores93.png'),
                SizedBox(
                  height: 20,
                ),
              Image.asset('assets/images/Mundial92.png'),
                SizedBox(
                  height: 20,
                ),
              Image.asset('assets/images/Libertadores92.png'),
                SizedBox(
                  height: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }
}