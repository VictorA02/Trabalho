import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:trabalhofinal/main.dart';


class TelaLogin extends StatefulWidget {
  const TelaLogin({ Key? key }) : super(key: key);

  @override
  _TelaLoginState createState() => _TelaLoginState();
}

class _TelaLoginState extends State<TelaLogin> {

  var _nome = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.only(
          top: 10,
        ),
        color: Colors.white,
        child: ListView(
          children: <Widget>[
            SizedBox(
              width: 400,
              height: 400,
              child: Image.asset('assets/images/Logo.jpg'),
            ),
            Container(
              padding: EdgeInsets.only(
                left: 100,
                right: 100,
              ),
              child: Column(
                children: [
                  TextField(
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      contentPadding: new EdgeInsets.fromLTRB(20, 23, 0, 23),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30)
                        ),
                      labelText: "Usuário",
                      labelStyle: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 25,
                      ),
                    ),
                    style: TextStyle(fontSize: 20,
                    color: Colors.black),
                    onChanged: (text) { _nome = text; },
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  TextField(
                    obscureText: true,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      isDense: true,
                      contentPadding: new EdgeInsets.fromLTRB(20, 23, 0, 23),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30)),
                      labelText: "Senha",
                      labelStyle: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 25,
                      )
                    ),
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  TextButton(
                    child: Text('Entrar'),
                    style: TextButton.styleFrom(
                      primary: Colors.black,
                      textStyle: TextStyle(fontSize: 25,
                      fontWeight: FontWeight.bold),
                    ),
                    onPressed: (){
                      Navigator.pushNamed(context, 'Tela Menu',
                      arguments: Mensagem(_nome));
                    }
                  )
                ],
              ),
            )
          ]
        )
      )
    );
  }
}