import 'package:flutter/material.dart';
import 'package:trabalhofinal/pages/tela.menu.novo.dart';
import 'package:trabalhofinal/pages/tela.noticias.dart';
import 'package:trabalhofinal/pages/tela.sobre.dart';

class TelaMenu extends StatefulWidget {
  const TelaMenu({ Key? key }) : super(key: key);

  @override
  _TelaMenuState createState() => _TelaMenuState();
}

class _TelaMenuState extends State<TelaMenu> {
  
  int currentIndex = 0;

  final screens = [
    TelaMenuNovo(),
    TelaNoticias(),
    TelaSobre(),
  ];

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      body: screens[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: (index) => setState(() => currentIndex = index),
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.red[800],
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.white.withOpacity(.40),
        selectedFontSize: 21,
        unselectedFontSize: 17,
        iconSize: 43,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Menu',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.article),
            label: 'Noticias',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.info),
            label: 'Sobre',
          ),
        ],
      ),
    );
  }
}