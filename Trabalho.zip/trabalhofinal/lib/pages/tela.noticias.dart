import 'package:flutter/material.dart';

class TelaNoticias extends StatelessWidget {
  const TelaNoticias({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red[900],
        title: Text('Noticias',
          style: TextStyle(color: Colors.black))
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(20),
          child: Column(            
            children: [
              Image.asset('assets/images/Noticia1.png'),
                SizedBox(
                  height: 20,
                ),
              Image.asset('assets/images/Noticia2.png'),
                SizedBox(
                  height: 20,
                ),
              Image.asset('assets/images/Noticia3.png'),
                SizedBox(
                  height: 20,
                ),
              Image.asset('assets/images/Noticia4.png'),
                SizedBox(
                  height: 20,
                ),
              Image.asset('assets/images/Noticia5.png'),
                SizedBox(
                  height: 20,
                ),
            ],
          ),
        ),
      ),
    );
  }
}