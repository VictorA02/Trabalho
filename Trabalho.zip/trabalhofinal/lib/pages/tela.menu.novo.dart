import 'package:flutter/material.dart';

class TelaMenuNovo extends StatelessWidget {
  const TelaMenuNovo({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title:
          Text('Seja bem vindo Usuário',
            style: TextStyle(color: Colors.black),
          ),
      ),
      body: Center(child:
        Container(
        padding: EdgeInsets.only(
            top: 10,
          ),
          color: Colors.white,
          child: ListView(
            children: <Widget>[
              Container(
                padding: EdgeInsets.only(
                  left: 50,
                  right: 50,
                ),
                child: Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    TextButton(
                      child: Text('Escalação do jogo de hoje!'),
                      style: TextButton.styleFrom(
                        primary: Colors.black,
                        textStyle: TextStyle(fontSize: 25,
                        fontWeight: FontWeight.bold),
                      ),
                      onPressed: (){
                        Navigator.pushNamed(context, 'Tela Escalacao');
                      }
                    ),
                    SizedBox(
                      height: 60,
                    ),
                    TextButton(
                      child: Text('Principais conquistas do SPFC'),
                      style: TextButton.styleFrom(
                        primary: Colors.black,
                        textStyle: TextStyle(fontSize: 25,
                        fontWeight: FontWeight.bold),
                      ),
                      onPressed: (){
                        Navigator.pushNamed(context, 'Tela Conquistas');
                      }
                    ),
                    SizedBox(
                      height: 60,
                    ),
                  ],
                ),
              )
            ]
          )
        )
      )
    );
  }
}