package com.example.trabalhofinal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
